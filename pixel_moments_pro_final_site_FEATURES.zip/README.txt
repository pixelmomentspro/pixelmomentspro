
Pixel Moments Pro — Final Website Bundle
---------------------------------------

Files included:
- Multi-page static site (HTML/CSS/JS)
- PixelMomentsPro_Contract.pdf (user-uploaded)
- Declining_Consent_Form_PixelMomentsPro.pdf (user-uploaded)
- style.css, lightbox.js
- README (this file)

Important notes:
- Booking page embeds the Google Form you provided.
- Contracts are included as PDFs. See /contracts.html.
- Declining Consent form included and also an online decline form that opens your email client.
- PayPal form uses 'your-paypal-email@example.com' as placeholder. Replace it in payment.html.
- Stripe link placeholder 'YOUR_STRIPE_CHECKOUT_URL' must be replaced with a server-generated Stripe Checkout URL.
- Client portal password (clientaccess) is stored in portal.html for demo. For secure client portals, we can set up server-side authentication.
- To accept automated payments and invoices, we recommend Stripe with a small serverless function or webhook to generate Checkout Sessions and track payments. I can set this up for you.

Deployment:
- Deploy to Netlify, Vercel, GitHub Pages, or Cloudflare Pages.
- For Stripe Checkout & webhooks, deploy a small serverless function (I can help).

If you'd like, I can publish this to Netlify or GitHub Pages and set up Stripe Checkout & automated invoicing.
