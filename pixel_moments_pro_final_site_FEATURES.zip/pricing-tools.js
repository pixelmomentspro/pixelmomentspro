
// pricing-tools.js - handles calculator, upsell suggestions, and minor animations
document.addEventListener('DOMContentLoaded', function(){
  const pkgSelect = document.getElementById('pkgSelect');
  const addonSetup = document.getElementById('addonSetup');
  const addonSound = document.getElementById('addonSound');
  const addonTransport = document.getElementById('addonTransport');
  const addonLighting = document.getElementById('addonLighting');
  const extraHours = document.getElementById('extraHours');
  const calcBtn = document.getElementById('calcBtn');
  const calcResult = document.getElementById('calcResult');
  const upsell = document.getElementById('upsellSuggestion');

  function calculateEstimate(){
    let base = parseFloat(pkgSelect.selectedOptions[0].dataset.price || 0);
    let total = base;
    if(addonSetup && addonSetup.checked) total += parseFloat(addonSetup.dataset.price);
    if(addonSound && addonSound.checked) total += parseFloat(addonSound.dataset.price);
    if(addonTransport && addonTransport.checked) total += parseFloat(addonTransport.dataset.price);
    if(addonLighting && addonLighting.checked) total += parseFloat(addonLighting.dataset.price);
    if(extraHours && extraHours.value) total += parseFloat(extraHours.value) * 350;
    calcResult.innerText = 'Estimated total: $' + total.toFixed(2);
    suggestUpsell(base, total);
  }

  function suggestUpsell(base, total){
    // Simple rules: if client selects Basic + many add-ons, suggest Standard or Premium
    const pkg = pkgSelect.value;
    if(pkg === 'basic' && (addonSetup.checked || addonSound.checked || addonLighting.checked || parseInt(extraHours.value) > 0)){
      upsell.innerText = 'Suggestion: For easier setup and better value, consider upgrading to the Standard or Premium package.';
    } else if(pkg === 'standard' && addonLighting.checked && parseInt(extraHours.value) >= 2){
      upsell.innerText = 'Suggestion: The Premium package may be a better fit for extended events with lighting.';
    } else {
      upsell.innerText = '';
    }
  }

  if(calcBtn){ calcBtn.addEventListener('click', calculateEstimate); }

  // Animated table: small entrance animation
  const table = document.querySelector('.comparison-table');
  if(table){
    table.style.opacity = 0;
    table.style.transform = 'translateY(8px)';
    setTimeout(()=>{ table.style.transition='all 400ms ease'; table.style.opacity=1; table.style.transform='translateY(0)'; }, 200);
  }

  // Recommended package highlight: pulse animation
  const rec = document.querySelectorAll('.recommended-badge');
  rec.forEach((el,i)=>{
    el.style.animation='pulse 2.6s ease-in-out infinite';
  });

  // Add keyframes dynamically
  const style = document.createElement('style');
  style.innerHTML = '@keyframes pulse {0% {transform:scale(1)} 50% {transform:scale(1.05)} 100% {transform:scale(1)} }';
  document.head.appendChild(style);
});
