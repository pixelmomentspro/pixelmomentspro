
document.addEventListener('DOMContentLoaded', function(){
  const gallery = document.getElementById('gallery-grid');
  if(gallery){
    gallery.addEventListener('click', function(e){
      const img = e.target.closest('img');
      if(!img) return;
      const full = img.getAttribute('data-full') || img.src;
      let lb = document.getElementById('lightbox');
      if(!lb){
        lb = document.createElement('div'); lb.id='lightbox'; lb.style.display='flex'; lb.style.position='fixed'; lb.style.inset='0'; lb.style.alignItems='center'; lb.style.justifyContent='center'; lb.style.background='rgba(0,0,0,0.8)'; lb.innerHTML='<img src="'+full+'" style="max-width:90%;max-height:90%;border-radius:8px">'; document.body.appendChild(lb);
        lb.addEventListener('click', function(){ lb.style.display='none'; lb.remove(); });
      }
    });
  }
});
